package queue;

import java.util.Scanner;

/**
 * @Author : weijunqi
 * @Description : //数组实现环形队列
 * @Date : Create in 14:41 2020/7/20
 * @Modify by :
 */
public class CircleArrayQueueDemo {
    public static void main(String[] args) {
        //创建一个队列
        CircleArrayQueue queue = new CircleArrayQueue(4);
        //接收用户输入
        char key;
        Scanner scanner = new Scanner(System.in);
        System.out.println("数组实现环形队列");
        boolean loop = true;
        //输出一个菜单
        while (loop) {
            System.out.println("s(show): 显示队列");
            System.out.println("e(exit): 退出队列");
            System.out.println("a(add): 添加数据到队列");
            System.out.println("g(get): 从队列取数据");
            System.out.println("h(head): 查看队列头的数据");

            //接收一个字符
            key = scanner.next().charAt(0);
            switch (key) {
                case 's':
                    queue.showQueue();
                    break;
                case 'a':
                    System.out.println("输入一个数");
                    int value = scanner.nextInt();
                    queue.addQueue(value);
                    break;
                case 'g':
                    try {
                        queue.getQueue();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 'h':
                    try {
                        queue.headQueue();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 'e':
                    scanner.close();
                    loop = false;
                    break;
                default:
                    break;
            }
        }

    }
}

/**
 * @Author : weijunqi
 * @Description :使用数组模拟队列
 * @Date : Create in 14:42 2020/7/20
 * @Modify by :
 */
    class CircleArrayQueue {
    //数组中的最大容量
    private int maxSize;
    //front指向队列的第一个元素,初始值=0;
    private int front;
    //rear指向队列的最后一个元素的后一个位置,预留一个空间作为约定;初始值=0;
    private int rear;
    //存储数据,模拟队列
    private int[] arr;

    public CircleArrayQueue(int arrMaxSize) {
        this.maxSize = arrMaxSize;
        this.arr = new int[maxSize];
    }

    //判断队列是否填满
    public boolean isFull() {
        return (rear + 1) % maxSize == front;
    }

    //判断队列是否为空
    public boolean isEmpty() {
        return rear == front;
    }

    //添加元素到队列
    public void addQueue(int n) {
        //判断队列是否填满
        if (isFull()) {
            System.out.println("队列已经被填满!!!");
            return;
        }
        //直接将数据加入
        arr[rear] = n;
        //将rear后移,要考虑取模
        rear = (rear + 1) % maxSize;
    }

    //获取队列中的数据,出列
    public int getQueue() {
        //判断队列是否为空
        if (isEmpty()) {
            throw new RuntimeException("队列为空,不能获取数据!!!");
        }
        //front++;  数组越界
        //(1)先将front对应的值保存在临时变量中
        //(2)将front后移,要考虑取模
        //(3)将临时变量返回
        int value = arr[front];
        front = (front + 1) % maxSize;
        return value;
    }

    //显示队列中的所有元素
    public void showQueue() {
        if (isEmpty()) {
            System.out.println("队列空的,没有数据~~~");
            return;
        }
        for (int i = front; i < front + size(); i++) {
            System.out.printf("arr[%d]=%d\n", i % maxSize, arr[i % maxSize]);
        }
    }

    //队列中有效个数
    private int size() {
        return (rear + maxSize - front) % maxSize;
    }

    //显示头数据,首位数据
    public int headQueue() {
        if (isEmpty()) {
            throw new RuntimeException("队列空的,没有数据~~~");
        }
        return arr[front];
    }

}
